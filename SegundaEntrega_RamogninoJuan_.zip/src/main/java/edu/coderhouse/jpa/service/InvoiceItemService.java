package edu.coderhouse.jpa.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import edu.coderhouse.jpa.repository.InvoiceItemRepository;
import edu.coderhouse.jpa.dto.InvoiceItemDTO;

import java.util.List;

@Service
public class InvoiceItemService {
    @Autowired
    private InvoiceItemRepository exampleRepository;

    public List<InvoiceItemDTO> getAllInvoiceItems() {
        // Just fetching all examples
        return exampleRepository.findAll();
    }

    public InvoiceItemDTO createInvoiceItem(InvoiceItemDTO example) {
        // Saving example and returning it
        return exampleRepository.save(example);
    }
}
