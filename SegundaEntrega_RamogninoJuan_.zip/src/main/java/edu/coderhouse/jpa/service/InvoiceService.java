package edu.coderhouse.jpa.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import edu.coderhouse.jpa.repository.InvoiceRepository;
import edu.coderhouse.jpa.dto.InvoiceDTO;

import java.util.List;

@Service
public class InvoiceService {
    @Autowired
    private InvoiceRepository exampleRepository;

    public List<InvoiceDTO> getAllInvoices() {
        // Just fetching all examples
        return exampleRepository.findAll();
    }

    public InvoiceDTO createInvoice(InvoiceDTO example) {
        // Saving example and returning it
        return exampleRepository.save(example);
    }
}
