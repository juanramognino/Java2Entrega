package edu.coderhouse.jpa.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import edu.coderhouse.jpa.repository.ExampleRepository;
import edu.coderhouse.jpa.dto.ExampleDTO;

import java.util.List;

@Service
public class ExampleService {
    @Autowired
    private ExampleRepository exampleRepository;

    public List<ExampleDTO> getAllExamples() {
        // Just fetching all examples
        return exampleRepository.findAll();
    }

    public ExampleDTO createExample(ExampleDTO example) {
        // Saving example and returning it
        return exampleRepository.save(example);
    }
}
