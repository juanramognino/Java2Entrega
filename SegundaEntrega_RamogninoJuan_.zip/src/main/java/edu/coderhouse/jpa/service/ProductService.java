package edu.coderhouse.jpa.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import edu.coderhouse.jpa.repository.ProductRepository;
import edu.coderhouse.jpa.dto.ProductDTO;

import java.util.List;

@Service
public class ProductService {
    @Autowired
    private ProductRepository exampleRepository;

    public List<ProductDTO> getAllProducts() {
        // Just fetching all examples
        return exampleRepository.findAll();
    }

    public ProductDTO createProduct(ProductDTO example) {
        // Saving example and returning it
        return exampleRepository.save(example);
    }
}
