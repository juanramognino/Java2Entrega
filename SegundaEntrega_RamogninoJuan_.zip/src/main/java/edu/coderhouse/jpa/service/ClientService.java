package edu.coderhouse.jpa.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import edu.coderhouse.jpa.repository.ClientRepository;
import edu.coderhouse.jpa.dto.ClientDTO;

import java.util.List;

@Service
public class ClientService {
    @Autowired
    private ClientRepository exampleRepository;

    public List<ClientDTO> getAllClients() {
        // Just fetching all examples
        return exampleRepository.findAll();
    }

    public ClientDTO createClient(ClientDTO example) {
        // Saving example and returning it
        return exampleRepository.save(example);
    }
}
