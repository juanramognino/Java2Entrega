package edu.coderhouse.jpa.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import edu.coderhouse.jpa.entity.ExampleEntity;

public interface ExampleRepository extends JpaRepository<ExampleEntity, Long> {
}
