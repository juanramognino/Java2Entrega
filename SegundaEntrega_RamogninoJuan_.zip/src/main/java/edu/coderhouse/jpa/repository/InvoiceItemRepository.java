package edu.coderhouse.jpa.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import edu.coderhouse.jpa.entity.InvoiceItem;

public interface InvoiceItemRepository extends JpaRepository<InvoiceItem, Long> {
}
