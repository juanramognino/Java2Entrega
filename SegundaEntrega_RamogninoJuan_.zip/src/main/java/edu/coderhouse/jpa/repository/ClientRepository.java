package edu.coderhouse.jpa.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import edu.coderhouse.jpa.entity.Client;

public interface ClientRepository extends JpaRepository<Client, Long> {
}
