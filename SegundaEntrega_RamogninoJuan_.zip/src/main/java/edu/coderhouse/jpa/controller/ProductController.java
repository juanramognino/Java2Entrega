package edu.coderhouse.jpa.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import edu.coderhouse.jpa.service.ProductService;
import edu.coderhouse.jpa.dto.ProductDTO;

import java.util.List;

@RestController
@RequestMapping("/examples")
public class ProductController {
    @Autowired
    private ProductService exampleService;

    // Get all examples
    @GetMapping
    public List<ProductDTO> getAll() {
        return exampleService.getAllProducts();
    }

    // Create a new example
    @PostMapping
    public ProductDTO createProduct(@RequestBody ProductDTO example) {
        return exampleService.createProduct(example);
    }
}
