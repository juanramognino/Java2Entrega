package edu.coderhouse.jpa.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import edu.coderhouse.jpa.service.InvoiceService;
import edu.coderhouse.jpa.dto.InvoiceDTO;

import java.util.List;

@RestController
@RequestMapping("/examples")
public class InvoiceController {
    @Autowired
    private InvoiceService exampleService;

    // Get all examples
    @GetMapping
    public List<InvoiceDTO> getAll() {
        return exampleService.getAllInvoices();
    }

    // Create a new example
    @PostMapping
    public InvoiceDTO createInvoice(@RequestBody InvoiceDTO example) {
        return exampleService.createInvoice(example);
    }
}
