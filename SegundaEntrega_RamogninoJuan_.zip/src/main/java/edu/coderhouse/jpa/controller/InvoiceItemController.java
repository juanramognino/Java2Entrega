package edu.coderhouse.jpa.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import edu.coderhouse.jpa.service.InvoiceItemService;
import edu.coderhouse.jpa.dto.InvoiceItemDTO;

import java.util.List;

@RestController
@RequestMapping("/examples")
public class InvoiceItemController {
    @Autowired
    private InvoiceItemService exampleService;

    // Get all examples
    @GetMapping
    public List<InvoiceItemDTO> getAll() {
        return exampleService.getAllInvoiceItems();
    }

    // Create a new example
    @PostMapping
    public InvoiceItemDTO createInvoiceItem(@RequestBody InvoiceItemDTO example) {
        return exampleService.createInvoiceItem(example);
    }
}
