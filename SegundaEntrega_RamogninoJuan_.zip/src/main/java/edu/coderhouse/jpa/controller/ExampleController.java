package edu.coderhouse.jpa.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import edu.coderhouse.jpa.service.ExampleService;
import edu.coderhouse.jpa.dto.ExampleDTO;

import java.util.List;

@RestController
@RequestMapping("/examples")
public class ExampleController {
    @Autowired
    private ExampleService exampleService;

    // Get all examples
    @GetMapping
    public List<ExampleDTO> getAll() {
        return exampleService.getAllExamples();
    }

    // Create a new example
    @PostMapping
    public ExampleDTO createExample(@RequestBody ExampleDTO example) {
        return exampleService.createExample(example);
    }
}
