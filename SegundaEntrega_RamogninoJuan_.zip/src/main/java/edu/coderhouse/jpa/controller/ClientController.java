package edu.coderhouse.jpa.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import edu.coderhouse.jpa.service.ClientService;
import edu.coderhouse.jpa.dto.ClientDTO;

import java.util.List;

@RestController
@RequestMapping("/examples")
public class ClientController {
    @Autowired
    private ClientService exampleService;

    // Get all examples
    @GetMapping
    public List<ClientDTO> getAll() {
        return exampleService.getAllClients();
    }

    // Create a new example
    @PostMapping
    public ClientDTO createClient(@RequestBody ClientDTO example) {
        return exampleService.createClient(example);
    }
}
